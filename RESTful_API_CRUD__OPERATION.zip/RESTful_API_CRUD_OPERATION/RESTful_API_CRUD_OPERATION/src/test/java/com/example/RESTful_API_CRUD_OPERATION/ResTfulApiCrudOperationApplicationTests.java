//package com.example.RESTful_API_CRUD_OPERATION;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class ResTfulApiCrudOperationApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
