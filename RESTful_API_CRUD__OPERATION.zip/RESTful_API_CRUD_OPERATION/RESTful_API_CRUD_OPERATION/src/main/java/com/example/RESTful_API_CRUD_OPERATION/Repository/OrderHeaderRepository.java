package com.example.RESTful_API_CRUD_OPERATION.Repository;


import com.example.RESTful_API_CRUD_OPERATION.Entity.OrderHeader;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderHeaderRepository extends JpaRepository<OrderHeader, Integer> {
}
