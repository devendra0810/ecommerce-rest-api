package com.example.RESTful_API_CRUD_OPERATION.Controller;


import com.example.RESTful_API_CRUD_OPERATION.Entity.OrderHeader;
import com.example.RESTful_API_CRUD_OPERATION.Entity.OrderItem;
import com.example.RESTful_API_CRUD_OPERATION.Service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    // Create Order
    @PostMapping
    public ResponseEntity<OrderHeader> createOrder(@RequestBody OrderHeader order) {
        return ResponseEntity.ok(orderService.createOrder(order));
    }

    // Retrieve Order Details
    @GetMapping("/{order_id}")
    public ResponseEntity<OrderHeader> getOrderDetails(@PathVariable int order_id) {
        return ResponseEntity.ok(orderService.getOrderDetails(order_id));
    }

    // Update Order
    @PutMapping("/{order_id}")
    public ResponseEntity<OrderHeader> updateOrder(
            @PathVariable int order_id,
            @RequestBody OrderHeader updatedOrder) {
        return ResponseEntity.ok(orderService.updateOrder(order_id, updatedOrder));
    }

    // Delete Order
    @DeleteMapping("/{order_id}")
    public ResponseEntity<String> deleteOrder(@PathVariable int order_id) {
        orderService.deleteOrder(order_id);
        return ResponseEntity.ok("Order deleted successfully.");
    }

    // Add Order Item
    @PostMapping("/{order_id}/items")
    public ResponseEntity<OrderItem> addOrderItem(
            @PathVariable int order_id,
            @RequestBody OrderItem orderItem) {
        return ResponseEntity.ok(orderService.addOrderItem(order_id, orderItem));
    }

    // Update Order Item
    @PutMapping("/{order_id}/items/{order_item_seq_id}")
    public ResponseEntity<OrderItem> updateOrderItem(
            @PathVariable int order_id,
            @PathVariable int order_item_seq_id,
            @RequestBody OrderItem updatedItem) {
        return ResponseEntity.ok(orderService.updateOrderItem(order_id, order_item_seq_id, updatedItem));
    }

    // Delete Order Item
    @DeleteMapping("/{order_id}/items/{order_item_seq_id}")
    public ResponseEntity<String> deleteOrderItem(
            @PathVariable int order_id,
            @PathVariable int order_item_seq_id) {
        orderService.deleteOrderItem(order_id, order_item_seq_id);
        return ResponseEntity.ok("Order item deleted successfully.");
    }
}
