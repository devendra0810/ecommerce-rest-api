package com.example.RESTful_API_CRUD_OPERATION;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResTfulApiCrudOperationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResTfulApiCrudOperationApplication.class, args);
	}

}
