package com.example.RESTful_API_CRUD_OPERATION.Service;


import com.example.RESTful_API_CRUD_OPERATION.Entity.OrderHeader;
import com.example.RESTful_API_CRUD_OPERATION.Entity.OrderItem;
import com.example.RESTful_API_CRUD_OPERATION.Repository.OrderHeaderRepository;
import com.example.RESTful_API_CRUD_OPERATION.Repository.OrderItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderService {

    @Autowired
    private OrderHeaderRepository orderRepository;

    @Autowired
    private OrderItemRepository orderItemRepository;

    // Create Order
    public OrderHeader createOrder(OrderHeader order) {
        return orderRepository.save(order);
    }

    // Retrieve Order Details
    public OrderHeader getOrderDetails(int orderId) {
        return orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + orderId));
    }

    // Update Order
    public OrderHeader updateOrder(int orderId, OrderHeader updatedOrder) {
        OrderHeader existingOrder = getOrderDetails(orderId);
        existingOrder.setShippingContactMech(updatedOrder.getShippingContactMech());
        existingOrder.setBillingContactMech(updatedOrder.getBillingContactMech());
        return orderRepository.save(existingOrder);
    }

    // Delete Order
    public void deleteOrder(int orderId) {
        orderRepository.deleteById(orderId);
    }

    // Add Order Item
    public OrderItem addOrderItem(int orderId, OrderItem orderItem) {
        OrderHeader order = getOrderDetails(orderId);
        orderItem.setOrder(order);
        return orderItemRepository.save(orderItem);
    }

    // Update Order Item
    public OrderItem updateOrderItem(int orderId, int orderItemSeqId, OrderItem updatedItem) {
        OrderItem existingItem = orderItemRepository.findById(orderItemSeqId)
                .orElseThrow(() -> new RuntimeException("Order item not found with ID: " + orderItemSeqId));

        existingItem.setQuantity(updatedItem.getQuantity());
        existingItem.setStatus(updatedItem.getStatus());
        return orderItemRepository.save(existingItem);
    }

    // Delete Order Item
    public void deleteOrderItem(int orderId, int orderItemSeqId) {
        orderItemRepository.deleteById(orderItemSeqId);
    }
}
